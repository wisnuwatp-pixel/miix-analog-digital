/**
 * Y2K Digital Heritage Icons
 * Inspired by the 1999–2005 era: Windows XP Luna, Mac OS X Aqua,
 * early internet browsers, and the analog-to-digital transition.
 */

interface IconProps {
  size?: number;
  className?: string;
}

/** Floppy Disk — the universal save symbol */
export function FloppyIcon({ size = 24, className = "" }: IconProps) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" className={className}>
      <defs>
        <linearGradient id="floppy-body" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor="#3a3a5c" />
          <stop offset="100%" stopColor="#1a1a2e" />
        </linearGradient>
        <linearGradient id="floppy-label" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor="#f0f0f0" />
          <stop offset="100%" stopColor="#c0c0c0" />
        </linearGradient>
        <linearGradient id="floppy-shine" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0%" stopColor="white" stopOpacity="0.3" />
          <stop offset="100%" stopColor="white" stopOpacity="0" />
        </linearGradient>
      </defs>
      <rect x="3" y="2" width="18" height="20" rx="1" fill="url(#floppy-body)" stroke="#2a2a4a" strokeWidth="0.5" />
      <rect x="3" y="2" width="18" height="20" rx="1" fill="url(#floppy-shine)" />
      <rect x="7" y="2" width="10" height="7" rx="0.5" fill="#1a1a2e" stroke="#4a4a6a" strokeWidth="0.5" />
      <rect x="11" y="3" width="2" height="5" rx="0.5" fill="#2a2a4a" />
      <rect x="5" y="12" width="14" height="8" rx="0.5" fill="url(#floppy-label)" stroke="#a0a0a0" strokeWidth="0.5" />
      <line x1="7" y1="14.5" x2="17" y2="14.5" stroke="#999" strokeWidth="0.5" />
      <line x1="7" y1="16.5" x2="14" y2="16.5" stroke="#999" strokeWidth="0.5" />
      <line x1="7" y1="18.5" x2="16" y2="18.5" stroke="#999" strokeWidth="0.5" />
    </svg>
  );
}

/** Hourglass — the classic wait cursor */
export function HourglassIcon({ size = 24, className = "" }: IconProps) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" className={className}>
      <defs>
        <linearGradient id="glass-frame" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0%" stopColor="#d4a843" />
          <stop offset="100%" stopColor="#8a6d42" />
        </linearGradient>
        <linearGradient id="glass-sand" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor="#c4734e" />
          <stop offset="100%" stopColor="#a05a3a" />
        </linearGradient>
      </defs>
      <rect x="5" y="2" width="14" height="2" rx="1" fill="url(#glass-frame)" />
      <rect x="5" y="20" width="14" height="2" rx="1" fill="url(#glass-frame)" />
      <path d="M7 4 L7 8 L12 12 L17 8 L17 4 Z" fill="url(#glass-sand)" opacity="0.3" />
      <path d="M7 20 L7 16 L12 12 L17 16 L17 20 Z" fill="url(#glass-sand)" />
      <path d="M7 4 L12 10 L17 4" fill="none" stroke="url(#glass-frame)" strokeWidth="1.5" />
      <path d="M7 20 L12 14 L17 20" fill="none" stroke="url(#glass-frame)" strokeWidth="1.5" />
      <circle cx="12" cy="12" r="1" fill="#d4a843" opacity="0.8" />
    </svg>
  );
}

/** CRT Monitor — the screen of the era */
export function CRTIcon({ size = 24, className = "" }: IconProps) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" className={className}>
      <defs>
        <linearGradient id="crt-body" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor="#e8e0d4" />
          <stop offset="100%" stopColor="#c0b8a8" />
        </linearGradient>
        <linearGradient id="crt-screen" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor="#0a2a1a" />
          <stop offset="100%" stopColor="#061a10" />
        </linearGradient>
      </defs>
      <rect x="2" y="3" width="20" height="15" rx="2" fill="url(#crt-body)" stroke="#a0a0a0" strokeWidth="0.5" />
      <rect x="4" y="5" width="16" height="11" rx="1" fill="url(#crt-screen)" />
      <line x1="4" y1="7" x2="20" y2="7" stroke="#00dbc2" strokeWidth="0.3" opacity="0.3" />
      <line x1="4" y1="9" x2="20" y2="9" stroke="#00dbc2" strokeWidth="0.3" opacity="0.3" />
      <line x1="4" y1="11" x2="20" y2="11" stroke="#00dbc2" strokeWidth="0.3" opacity="0.3" />
      <line x1="4" y1="13" x2="20" y2="13" stroke="#00dbc2" strokeWidth="0.3" opacity="0.3" />
      <text x="6" y="10" fontFamily="monospace" fontSize="3" fill="#00dbc2" opacity="0.8">C:\&gt;_</text>
      <rect x="8" y="19" width="8" height="2" rx="0.5" fill="#a0a0a0" />
      <circle cx="12" cy="16.5" r="0.8" fill="#888" />
    </svg>
  );
}

/** Browser Window — early internet navigation */
export function BrowserIcon({ size = 24, className = "" }: IconProps) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" className={className}>
      <defs>
        <linearGradient id="browser-bar" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor="#e0e8f0" />
          <stop offset="100%" stopColor="#b8c8d8" />
        </linearGradient>
      </defs>
      <rect x="2" y="3" width="20" height="18" rx="2" fill="#1a1410" stroke="#00dbc2" strokeWidth="0.5" opacity="0.8" />
      <rect x="2" y="3" width="20" height="4" rx="2" fill="url(#browser-bar)" />
      <rect x="2" y="5" width="20" height="2" fill="url(#browser-bar)" />
      <circle cx="5" cy="5" r="0.8" fill="#ff5f57" />
      <circle cx="7.5" cy="5" r="0.8" fill="#febc2e" />
      <circle cx="10" cy="5" r="0.8" fill="#28c840" />
      <rect x="12" y="4" width="8" height="1.5" rx="0.5" fill="white" opacity="0.6" />
      <path d="M6 9 L10 9 L8 12 Z" fill="#4a90d9" opacity="0.8" />
      <path d="M18 9 L14 9 L16 12 Z" fill="#4a90d9" opacity="0.5" />
      <rect x="4" y="10" width="16" height="9" rx="0.5" fill="#0e1a2a" />
      <text x="6" y="14" fontFamily="monospace" fontSize="2.5" fill="#00dbc2" opacity="0.6">http://</text>
      <text x="6" y="17" fontFamily="monospace" fontSize="2" fill="#888">Loading...</text>
    </svg>
  );
}

/** RSS Feed — the early syndication icon */
export function RSSIcon({ size = 24, className = "" }: IconProps) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" className={className}>
      <defs>
        <linearGradient id="rss-orange" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0%" stopColor="#ff8c00" />
          <stop offset="100%" stopColor="#d4a843" />
        </linearGradient>
      </defs>
      <circle cx="5" cy="19" r="3" fill="url(#rss-orange)" />
      <path d="M5 13 A6 6 0 0 1 11 19" fill="none" stroke="url(#rss-orange)" strokeWidth="2" strokeLinecap="round" />
      <path d="M5 7 A12 12 0 0 1 17 19" fill="none" stroke="url(#rss-orange)" strokeWidth="2" strokeLinecap="round" />
    </svg>
  );
}

/** Globe with Grid — the World Wide Web symbol */
export function GlobeIcon({ size = 24, className = "" }: IconProps) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" className={className}>
      <defs>
        <linearGradient id="globe-blue" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0%" stopColor="#00dbc2" />
          <stop offset="100%" stopColor="#0088aa" />
        </linearGradient>
      </defs>
      <circle cx="12" cy="12" r="10" fill="none" stroke="url(#globe-blue)" strokeWidth="1.5" />
      <ellipse cx="12" cy="12" rx="4" ry="10" fill="none" stroke="url(#globe-blue)" strokeWidth="0.8" />
      <line x1="2" y1="8" x2="22" y2="8" stroke="url(#globe-blue)" strokeWidth="0.6" />
      <line x1="2" y1="16" x2="22" y2="16" stroke="url(#globe-blue)" strokeWidth="0.6" />
      <line x1="12" y1="2" x2="12" y2="22" stroke="url(#globe-blue)" strokeWidth="0.6" />
    </svg>
  );
}

/** Lock — early web security */
export function LockIcon({ size = 24, className = "" }: IconProps) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" className={className}>
      <defs>
        <linearGradient id="lock-body" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor="#d4a843" />
          <stop offset="100%" stopColor="#8a6d42" />
        </linearGradient>
      </defs>
      <rect x="5" y="11" width="14" height="11" rx="2" fill="url(#lock-body)" />
      <path d="M8 11 V7 A4 4 0 0 1 16 7 V11" fill="none" stroke="url(#lock-body)" strokeWidth="2" />
      <circle cx="12" cy="16" r="1.5" fill="#1a1410" />
      <line x1="12" y1="17.5" x2="12" y2="19" stroke="#1a1410" strokeWidth="1.5" />
    </svg>
  );
}

/** Speech Bubble — instant messaging era (AIM, ICQ, MSN) */
export function ChatBubbleIcon({ size = 24, className = "" }: IconProps) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" className={className}>
      <defs>
        <linearGradient id="bubble-blue" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor="#5b9bd5" />
          <stop offset="100%" stopColor="#3a7cc0" />
        </linearGradient>
      </defs>
      <path d="M4 4 h16 a2 2 0 0 1 2 2 v10 a2 2 0 0 1 -2 2 h-10 l-4 4 v-4 h-2 a2 2 0 0 1 -2 -2 v-10 a2 2 0 0 1 2 -2z" fill="url(#bubble-blue)" />
      <circle cx="8" cy="11" r="1" fill="white" opacity="0.8" />
      <circle cx="12" cy="11" r="1" fill="white" opacity="0.8" />
      <circle cx="16" cy="11" r="1" fill="white" opacity="0.8" />
    </svg>
  );
}

/** Pixel Star — favorites and ratings */
export function PixelStarIcon({ size = 24, className = "" }: IconProps) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" className={className}>
      <defs>
        <linearGradient id="star-gold" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0%" stopColor="#ffd700" />
          <stop offset="100%" stopColor="#d4a843" />
        </linearGradient>
      </defs>
      <polygon points="12,2 14.5,9 22,9 16,13.5 18,21 12,17 6,21 8,13.5 2,9 9.5,9" fill="url(#star-gold)" stroke="#b8940a" strokeWidth="0.5" />
      <polygon points="12,2 14.5,9 22,9 16,13.5 18,21 12,17 6,21 8,13.5 2,9 9.5,9" fill="white" opacity="0.15" />
    </svg>
  );
}

/** Folder — the yellow manila folder */
export function FolderIcon({ size = 24, className = "" }: IconProps) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" className={className}>
      <defs>
        <linearGradient id="folder-front" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor="#ffd700" />
          <stop offset="100%" stopColor="#d4a843" />
        </linearGradient>
        <linearGradient id="folder-back" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor="#e6c200" />
          <stop offset="100%" stopColor="#b8940a" />
        </linearGradient>
      </defs>
      <path d="M2 6 L2 19 a2 2 0 0 0 2 2 h16 a2 2 0 0 0 2 -2 v-11 a2 2 0 0 0 -2 -2 h-8 l-2 -3 h-8 a2 2 0 0 0 -2 2z" fill="url(#folder-back)" />
      <path d="M2 10 h20 v9 a2 2 0 0 1 -2 2 h-16 a2 2 0 0 1 -2 -2z" fill="url(#folder-front)" />
      <path d="M2 10 h20 v1 h-20z" fill="white" opacity="0.2" />
    </svg>
  );
}

/** Running Man — MSN Messenger / AIM status */
export function RunningManIcon({ size = 24, className = "" }: IconProps) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" className={className}>
      <defs>
        <linearGradient id="man-green" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0%" stopColor="#28c840" />
          <stop offset="100%" stopColor="#1a9a30" />
        </linearGradient>
      </defs>
      <circle cx="12" cy="5" r="2.5" fill="url(#man-green)" />
      <path d="M8 9 L12 8 L16 9 L15 15 L17 22 L12 19 L7 22 L9 15 Z" fill="url(#man-green)" />
      <path d="M8 9 L4 12" stroke="url(#man-green)" strokeWidth="1.5" strokeLinecap="round" />
      <path d="M16 9 L20 7" stroke="url(#man-green)" strokeWidth="1.5" strokeLinecap="round" />
    </svg>
  );
}

/** Butterfly — MSN Messenger */
export function ButterflyIcon({ size = 24, className = "" }: IconProps) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" className={className}>
      <defs>
        <linearGradient id="bfly-orange" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0%" stopColor="#ff8c00" />
          <stop offset="100%" stopColor="#d4a843" />
        </linearGradient>
        <linearGradient id="bfly-green" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0%" stopColor="#28c840" />
          <stop offset="100%" stopColor="#1a9a30" />
        </linearGradient>
        <linearGradient id="bfly-blue" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0%" stopColor="#5b9bd5" />
          <stop offset="100%" stopColor="#3a7cc0" />
        </linearGradient>
        <linearGradient id="bfly-red" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0%" stopColor="#e74c3c" />
          <stop offset="100%" stopColor="#c0392b" />
        </linearGradient>
      </defs>
      <ellipse cx="8" cy="8" rx="5" ry="4" fill="url(#bfly-orange)" transform="rotate(-20 8 8)" />
      <ellipse cx="16" cy="8" rx="5" ry="4" fill="url(#bfly-green)" transform="rotate(20 16 8)" />
      <ellipse cx="8" cy="15" rx="4" ry="3.5" fill="url(#bfly-blue)" transform="rotate(15 8 15)" />
      <ellipse cx="16" cy="15" rx="4" ry="3.5" fill="url(#bfly-red)" transform="rotate(-15 16 15)" />
      <line x1="12" y1="4" x2="12" y2="20" stroke="#2a2218" strokeWidth="1" />
    </svg>
  );
}

/** Windows Flag — simplified */
export function WindowsFlagIcon({ size = 24, className = "" }: IconProps) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" className={className}>
      <rect x="2" y="2" width="9" height="9" rx="1" fill="#f25022" />
      <rect x="13" y="2" width="9" height="9" rx="1" fill="#7fba00" />
      <rect x="2" y="13" width="9" height="9" rx="1" fill="#00a4ef" />
      <rect x="13" y="13" width="9" height="9" rx="1" fill="#ffb900" />
    </svg>
  );
}

/** Happy Mac — Mac boot icon */
export function HappyMacIcon({ size = 24, className = "" }: IconProps) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" className={className}>
      <defs>
        <linearGradient id="mac-body" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor="#e8e0d4" />
          <stop offset="100%" stopColor="#c0b8a8" />
        </linearGradient>
      </defs>
      <rect x="4" y="2" width="16" height="14" rx="3" fill="url(#mac-body)" stroke="#a0a0a0" strokeWidth="0.5" />
      <rect x="6" y="4" width="12" height="8" rx="1" fill="#1a2a1a" />
      <circle cx="9" cy="7" r="1" fill="#00dbc2" />
      <circle cx="15" cy="7" r="1" fill="#00dbc2" />
      <path d="M9 10 Q12 12 15 10" fill="none" stroke="#00dbc2" strokeWidth="0.8" />
      <rect x="9" y="16" width="6" height="1" rx="0.5" fill="#a0a0a0" />
      <rect x="7" y="17" width="10" height="5" rx="1" fill="url(#mac-body)" stroke="#a0a0a0" strokeWidth="0.5" />
    </svg>
  );
}

/** CD/Disc — optical media */
export function CDDiscIcon({ size = 24, className = "" }: IconProps) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" className={className}>
      <defs>
        <linearGradient id="cd-rainbow" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0%" stopColor="#ff6b6b" />
          <stop offset="25%" stopColor="#d4a843" />
          <stop offset="50%" stopColor="#28c840" />
          <stop offset="75%" stopColor="#5b9bd5" />
          <stop offset="100%" stopColor="#9b59b6" />
        </linearGradient>
      </defs>
      <circle cx="12" cy="12" r="10" fill="url(#cd-rainbow)" opacity="0.3" />
      <circle cx="12" cy="12" r="10" fill="none" stroke="url(#cd-rainbow)" strokeWidth="1" />
      <circle cx="12" cy="12" r="3" fill="#1a1410" stroke="url(#cd-rainbow)" strokeWidth="0.5" />
      <circle cx="12" cy="12" r="1" fill="url(#cd-rainbow)" opacity="0.5" />
      <circle cx="12" cy="12" r="7" fill="none" stroke="url(#cd-rainbow)" strokeWidth="0.3" opacity="0.5" />
    </svg>
  );
}

/** Progress Bar — chunky Y2K style */
export function ProgressBarIcon({ size = 24, className = "" }: IconProps) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" className={className}>
      <defs>
        <linearGradient id="prog-fill" x1="0" y1="0" x2="1" y2="0">
          <stop offset="0%" stopColor="#00dbc2" />
          <stop offset="100%" stopColor="#00b8a1" />
        </linearGradient>
      </defs>
      <rect x="2" y="8" width="20" height="8" rx="1" fill="#1a1410" stroke="#2a2218" strokeWidth="1" />
      <rect x="3" y="9" width="4" height="6" rx="0.5" fill="url(#prog-fill)" />
      <rect x="8" y="9" width="4" height="6" rx="0.5" fill="url(#prog-fill)" />
      <rect x="13" y="9" width="4" height="6" rx="0.5" fill="url(#prog-fill)" />
      <rect x="18" y="9" width="3" height="6" rx="0.5" fill="url(#prog-fill)" opacity="0.3" />
    </svg>
  );
}
